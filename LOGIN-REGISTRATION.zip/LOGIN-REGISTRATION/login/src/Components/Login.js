import {useState, useContext} from "react"
import {useNavigate} from "react-router-dom"
import { Contextapi } from "./Contextapi"

import {Link} from "react-router-dom"
function Login() {
    const{setLoginname} =useContext(Contextapi)
    const navigate= useNavigate()
const[email,setMail]=useState('')
const[password,setPasssword]=useState('')
const[message,setMessage]=useState('')
function handlelogin(e){
 e.preventDefault()
 const data={email,password}
 fetch('/login',{
   method:'POST',
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify(data)
 }).then((result)=>{return result.json()}).then((data)=>{
        console.log(data)
        if(data.status===200){
            setMessage(data.message)
            localStorage.setItem('loginname',data.apiData.Email)
             setLoginname(localStorage.getItem('loginname'))
            navigate(`/details`)
        }else{
            setMessage(data.message)
        }
 })
}
    return ( 
        <section id="login">
             <div className="container">
        <div className="row">
            <div className="col-md-12">
                <div className="registration">
                    <h1>Login Page</h1>
                    <p>{message}</p>
                    <form className="form-control" onSubmit={(e)=>{handlelogin(e)}}>
                        <label>Email</label>
                        <input type="Email" className="form-control"
                        value={email}
                        onChange={(e)=>{setMail(e.target.value)}}
                        ></input>
                        <label>Password</label>
                        <input type="password" className="form-control"
                        value={password}
                        onChange={(e)=>{setPasssword(e.target.value)}}
                        ></input>
                        <button type="submit" className="btn btn-primary form-control mt-3 mb-2">Login</button>
                        <h4 style={{textAlign:"center"}}>OR</h4>
                        <Link style={{textDecoration:"none",color:"white"}} to="/"> <button className="btn btn-success form-control mt-3 mb-2">Doesn't have any account?Register</button></Link>
                    </form>
                </div>
            </div>
        </div>
    </div>
        </section>
       
     );
}

export default Login;