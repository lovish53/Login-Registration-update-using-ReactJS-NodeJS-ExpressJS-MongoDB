import { useState, useEffect, useContext} from "react";
import {useParams, useNavigate} from "react-router-dom";
import { Contextapi } from "./Contextapi";



function Update() {

    const[firstname,setFirst]= useState('')
    const[lastname,setLast]= useState('')
    const[password,setPass]= useState('')
    const[email,setMail]=useState('')
    const[mobile,setMobile]=useState('')
    const[message,setMessage]=useState('')
    const{id}=useParams()
    const navigate=useNavigate()
    const{loginname,setLoginname}=useContext(Contextapi)
    useEffect(()=>{
        fetch(`/singledata/${id}`).then((result)=>{return result.json()}).then((data)=>{
        console.log(data)
          if(data.status===200){
            setFirst(data.apiData.Fname)
            setLast(data.apiData.Lname)
            setMail(data.apiData.Email)
            setPass(data.apiData.Password)
            setMobile(data.apiData.Mobile)
            setMessage(data.message)
          }else{
               setMessage(data.message)
          }
      })
       },[])
    function handleform(e){
        e.preventDefault()

        const data={firstname,lastname,email,mobile,password}
        fetch(`/updateform/${id}`,{
            method:"PUT",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
            // console.log(data)
            if(data.status===200){
                setMessage(data.message)
                navigate('/details')
            }else{
                 setMessage(data.message)
            }
        })
    }

    function handlelogout(e){
      
        localStorage.removeItem('loginname')
        setLoginname(localStorage.getItem('loginname'))
        navigate('/login')
      }
    return ( 
        <section id="login">
             <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="registration">
                            <h1>Update Page</h1>
                            <div className="d-flex gap-2" style={{justifyContent:"center"}}>
                          <p style={{marginTop:"10px"}}>{loginname}</p>
                        <button className="btn btn-danger" onClick={(e)=>{handlelogout(e)}}>Logout</button>
                          </div>
                            <p>{message}</p>
                            <form className="form-control" onSubmit={(e)=>{handleform(e)}}>
                                <label>First Name</label>
                                <input type="text" className="form-control"
                                value={firstname}
                                onChange={(e)=>{setFirst(e.target.value)}}
                                ></input>
                                <label>Last Name</label>
                                <input type="text" className="form-control"
                                value={lastname}
                                onChange={(e)=>{setLast(e.target.value)}}
                                ></input>
                                <label>Email</label>
                                <input type="Email" className="form-control"
                                value={email}
                                onChange={(e)=>{setMail(e.target.value)}}
                                ></input>
                                <label>Mobile</label>
                                <input type="number" className="form-control"
                                value={mobile}
                                onChange={(e)=>{setMobile(e.target.value)}}
                                ></input>
                                <label>Password</label>
                                <input type="password" className="form-control"
                                value={password}
                                onChange={(e)=>{setPass(e.target.value)}}
                                ></input>
                                <button type="submit" className="btn btn-primary form-control mt-3 mb-2">Update</button>
                               
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
       
     );
}

export default Update;