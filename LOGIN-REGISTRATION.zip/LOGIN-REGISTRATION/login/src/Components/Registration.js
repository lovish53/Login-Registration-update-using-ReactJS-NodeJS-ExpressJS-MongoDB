import {Link} from "react-router-dom"
import {useState} from "react"
function Registration() {
   const[firstname,setFirst]= useState('')
   const[lastname,setLast]= useState('')
   const[password,setPass]= useState('')
   const[email,setMail]=useState('')
   const[mobile,setMobile]=useState('')
   const[message,setMessage]=useState('')
    
   function handleform(e){
    e.preventDefault()
    const data={firstname,lastname,password,email,mobile}
    //console.log(data)
    fetch('/',{
       method:"POST",
       headers:{"Content-Type":"application/json"},
       body:JSON.stringify(data)
    }).then((result)=>{return result.json()}).then((data)=>{
      console.log(data)
       if(data.status===201){
          setMessage('Username Succefully Created')
       }else{
           setMessage(data.message)
       }
    })
   }
    return (
        <>
        <section id="login">
        <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="registration">
                            <h1>Registration Page</h1>
                            <p>{message}</p>
                            <form className="form-control" onSubmit={(e)=>{handleform(e)}}>
                                <label>First Name</label>
                                <input type="text" className="form-control"
                                value={firstname}
                                onChange={(e)=>{setFirst(e.target.value)}}
                                ></input>
                                <label>Last Name</label>
                                <input type="text" className="form-control"
                                value={lastname}
                                onChange={(e)=>{setLast(e.target.value)}}
                                ></input>
                                <label>Email</label>
                                <input type="Email" className="form-control"
                                value={email}
                                onChange={(e)=>{setMail(e.target.value)}}
                                ></input>
                                <label>Mobile</label>
                                <input type="number" className="form-control"
                                value={mobile}
                                onChange={(e)=>{setMobile(e.target.value)}}
                                ></input>
                                <label>Password</label>
                                <input type="password" className="form-control"
                                value={password}
                                onChange={(e)=>{setPass(e.target.value)}}
                                ></input>
                                <button type="submit" className="btn btn-primary form-control mt-3 mb-2">Register</button>
                                <h4 style={{textAlign:"center"}}>OR</h4>
                                <Link style={{textDecoration:"none", color:"white"}} to="/login"> <button className="btn btn-success form-control mt-3 mb-2">Already have an account?Login</button></Link>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
           
        </>
    );
}

export default Registration;