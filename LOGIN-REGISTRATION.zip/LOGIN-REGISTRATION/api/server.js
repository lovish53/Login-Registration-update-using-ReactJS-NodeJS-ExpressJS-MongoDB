const express=require('express')
const app = express()
app.use(express.json())
const apiRouter=require('./router/apiRouter')
const mongoose=require('mongoose')
require('dotenv').config()
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)





app.use(apiRouter)
app.use(express.static('public'))
app.listen(process.env.PORT,()=>{console.log('server is running on port 5000')})