const Reg=require('../models/reg')

exports.register=async(req,res)=>{
try{
    const{firstname,lastname,email,mobile,password}=req.body

    const usercheck= await Reg.findOne({Email:email})
    if(usercheck==null){
     const record=new Reg({Fname:firstname,Lname:lastname,Email:email,Mobile:mobile,Password:password})
     record.save()
     res.json({
      status:201,
      apiData:record,
      message:'Succefully Registered'
     })
    }else{
     res.json({
         status:400,
         message:'Username is already taken'
     })
    }
     }catch(error){
     res.json({
         status:400,
         message:error.message
     })
     }

}

exports.login=async(req,res)=>{
    try{
        const{email,password}=req.body
        const id= req.params.id
        const record=await Reg.findOne(id,{Email:email,Password:password})
        if(record!==null){
            if(record.Password==password){
                res.json({
                    status:200,
                    apiData:record,
                   })
            }else{
                res.json({
                    status:400,
                    message:'Wrong Credentials'
                })
            }
        }else{
            res.json({
                status:400,
                message:'Wrong Credentials'
            })
        }
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })
    }

}

exports.details=async(req,res)=>{
    try{
        const record= await Reg.find()
        res.json({
         status:200,
         apiData:record
        })
       }catch(error){
         res.json({
           status:500,
           message:error.message
         })
       }
     }

     exports.singledata=async(req,res)=>{
        try{
           const id=req.params.id
          const record= await Reg.findById(id)
          res.json({
            status:200,
            apiData:record
          })
      }catch(error){
        res.json({
          status:500,
          error:error.message
        })
      }
      } 
      
      exports.updateform=async(req,res)=>{
        const id=req.params.id
        const{firstname,lastname,email,mobile,password}=req.body
        try{
        await Reg.findByIdAndUpdate(id,{Fname:firstname,Lname:lastname,Email:email,Mobile:mobile,Password:password})
         res.json({
          status:200,
          message:"Successfully Updated"
         })
        }catch(error){
          res.json({
            status:500,
            message:error.message
          })
        }
      }