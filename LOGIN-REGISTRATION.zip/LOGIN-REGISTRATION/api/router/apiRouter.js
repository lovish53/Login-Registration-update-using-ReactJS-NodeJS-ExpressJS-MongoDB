const router=require("express").Router();
const regc=require('../controllers/regccontroller');

router.post('/',regc.register)
router.post('/login',regc.login)
router.get('/details',regc.details)
router.get('/singledata/:id',regc.singledata)
router.put('/updateform/:id',regc.updateform)






module.exports= router